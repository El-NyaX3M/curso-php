function setup() {
  createCanvas(960, 260);
}

function draw() {
  const width = 120;
  const height = 230;
  let x = 15;
  let y = 15;
  
  background("rgb(185,211,221)");
  /*let bkX = 0;
  let bkY = 5;
  let bkWidth = 25;
  
  fill("rgb(131,132,136)");
  stroke("rgb(131,132,136)")
  while(bkY < 270){
    ellipse(bkX, bkY, bkWidth);
    bkX += bkWidth + 2;
    if(bkX > 970) {
      bkX = 0;
      bkY += bkWidth + 2;
    }
  }
  */
  strokeWeight(4);
  for(let i = 0; i < 7; i++){
    stroke("#6C7F97");
    fill("#94ADB1");
    rect(x,y,width,height,20);
    
    line(x, (y + height/2), (x + width), (y + height/2));
    
    fill("#FFC107");
    circle((x + width/2), (y + height/2), 20);
    
    stroke("#6C7F97");
    fill("#6C7F97");
    switch(i){
      case 1:    
        circle((x + width/2), (y + height/4),45);
        circle((x + width/2), (y + 3*height/4),45);
        break;
        
      case 2:
        for(let j = 0; j < 14; j++){
            if(j == 0 || j == 4 || j == 9 || j == 13){
              if(j < 7) circle((x + width/4), (y + (j+1)*height/8), 20);
              
              else circle((x + 3*width/4), (y + (j-6)*height/8), 20);
            }
        }
        break;
        
      case 3:
        for(let j = 0; j < 21; j++){
            if(!(j % 4)){
              if(j < 7){
                circle((x + width/4), (y + (j+1)*height/8), 20);
              }
              else if(j < 14){
                circle((x + 2*width/4), (y + (j-6)*height/8), 20);
              }
              else{
                circle((x + 3*width/4), (y + (j-13)*height/8), 20);
              }
            }
        }
        break;
      case 4:
        for(let j = 0; j < 15; j++){
            if(!(j % 2)){
              if(j < 8){
                circle((x + width/4), (y + (j+1)*height/8), 20);
              }
              else{
                circle((x + 3*width/4), (y + (j-7)*height/8), 20);
              }
            }
        }
        break;
      case 5:
        for(let j = 0; j < 21; j++){
            if(!(j % 2) && j != 10){
              if(j < 7){
                circle((x + width/4), (y + (j+1)*height/8), 20);
              }
              else if(j < 14){
                circle((x + 2*width/4), (y + (j-6)*height/8), 20);
              }
              else{
                circle((x + 3*width/4), (y + (j-13)*height/8), 20);
              }
            }
        }
        break;
        
      case 6:
        for(let j = 0; j < 14; j++){
            if(j != 3 && j != 10){
              if(j < 7){
                circle((x + width/4), (y + (j+1)*height/8), 20);
              }
              else{
                circle((x + 3*width/4), (y + (j-6)*height/8), 20);
              }
            }
        }
        break;
        
    }
    
    x += width + 15;
  }
  
}